<article class="mkdf-pvl-item <?php echo esc_attr( $this_object->getArticleClasses() ); ?>">
	<div class="mkdf-pvl-item-inner">
		<?php echo grandprix_core_get_cpt_shortcode_module_template_part( 'portfolio', 'portfolio-vertical-loop', 'layout-collections/standard', '', $params, $additional_params ); ?>
    </div>
</article>