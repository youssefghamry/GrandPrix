<?php

get_header();

grandprix_mikado_get_title();

do_action('grandprix_mikado_action_before_main_content');

grandprix_core_get_single_portfolio();

get_footer();