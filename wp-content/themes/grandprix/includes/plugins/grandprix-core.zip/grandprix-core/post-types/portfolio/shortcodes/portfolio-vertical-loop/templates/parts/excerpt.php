<?php $excerpt = get_the_excerpt(); ?>

<p itemprop="description" class="mkdf-pvli-excerpt"><?php echo esc_html($excerpt); ?></p>
