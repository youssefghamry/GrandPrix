<?php

include_once GRANDPRIX_CORE_ABS_PATH . '/like/like.php';
include_once GRANDPRIX_CORE_ABS_PATH . '/like/like-functions.php';