<div class="mkdf-clients-carousel-holder <?php echo esc_attr($holder_classes); ?>">
	<div class="mkdf-cc-inner mkdf-owl-slider" <?php echo grandprix_mikado_get_inline_attrs($carousel_data); ?>>
		<?php echo do_shortcode($content); ?>
	</div>
</div>