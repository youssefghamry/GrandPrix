<?php

include_once GRANDPRIX_CORE_SHORTCODES_PATH . '/pie-chart/functions.php';
include_once GRANDPRIX_CORE_SHORTCODES_PATH . '/pie-chart/pie-chart.php';