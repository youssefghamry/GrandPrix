<?php

include_once GRANDPRIX_CORE_SHORTCODES_PATH . '/dual-image-carousel/functions.php';
include_once GRANDPRIX_CORE_SHORTCODES_PATH . '/dual-image-carousel/dual-image-carousel.php';